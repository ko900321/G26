export { default as Detail } from './Detail';
export { default as InfoText } from './InfoText';
export { default as Link } from './Link';
export { default as Wrapper } from './Wrapper';
