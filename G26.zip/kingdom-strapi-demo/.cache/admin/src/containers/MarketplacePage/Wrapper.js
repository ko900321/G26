import styled from 'styled-components';
import ContainerFluid from '../../components/ContainerFluid';

const Wrapper = styled(ContainerFluid)`
  > div:first-child {
    margin-bottom: 11px;
  }
`;

export default Wrapper;
