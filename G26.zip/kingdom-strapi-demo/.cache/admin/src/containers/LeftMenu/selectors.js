const selectMenuLinks = state => state.get('menu');

export default selectMenuLinks;
