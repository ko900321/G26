const checkIfAllEntriesAreSelected = data => data.every(obj => obj._isChecked === true);

export default checkIfAllEntriesAreSelected;
